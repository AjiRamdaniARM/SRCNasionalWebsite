<x-panel.app>

    <div id="team" class="section relative pt-20 pb-8 md:pt-16">
        <div class="container xl:max-w-6xl mx-auto px-4">
            <!-- section header -->
            <header class="text-center mx-auto mb-12">
                <h2 class="text-2xl leading-normal mb-2 font-bold text-gray-800 dark:text-gray-100">
                    <span class="font-light">Participants</span> Perlombaan
                </h2>
                <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 100 60" style="margin: 0 auto;height: 35px;" xml:space="preserve">
                    <circle cx="50.1" cy="30.4" r="5" class="stroke-primary" style="fill: transparent;stroke-width: 2;stroke-miterlimit: 10;"></circle>
                    <line x1="55.1" y1="30.4" x2="100" y2="30.4" class="stroke-primary" style="stroke-width: 2;stroke-miterlimit: 10;"></line>
                    <line x1="45.1" y1="30.4" x2="0" y2="30.4" class="stroke-primary" style="stroke-width: 2;stroke-miterlimit: 10;"></line>
                </svg>
            </header>
            <!-- end section header -->
            <!-- row -->
            <div class="flex flex-wrap flex-row -mx-4 justify-center">
                @foreach ($data as $datas )
                <div class="flex-shrink max-w-full px-4 w-2/3 sm:w-1/2 md:w-5/12 lg:w-1/4 xl:px-6">
                    <div class="relative overflow-hidden bg-white dark:bg-gray-800 mb-12 hover-grayscale-0 wow fadeInUp rounded-2xl p-5" data-wow-duration="1s" style="visibility: visible; animation-duration: 1s; animation-name: fadeInUp;">
                        <!-- team block -->
                        <div class="relative overflow-hidden px-6">
                            <img src="{{asset('assets/animasi2.gif')}}" class="max-w-full h-auto mx-auto rounded-full bg-gray-50 " alt="title image">
                        </div>
                        <div class="pt-6 text-center">
                            <p class="text-lg leading-normal font-bold mb-1">{{$datas->name}}</p>
                            <p class="text-gray-500 leading-relaxed font-light">Founder CEO</p>
                            <!-- social icon -->

                        </div>
                    </div>
                    <!-- end team block -->
                </div>
                @endforeach

            </div>
            <!-- end row -->
        </div>
    </div>
</x-panel.app>
