Projek ini adalah projek tim yang dibuat oleh Alfatur Wicaksono & Wisnutama prasetya putra
Webpage ini menjelaskan tentang 3 jenis robot unik.
Webpage ini hanya terbuat dari html dan css sederhana.