# Aplikasi-Kasir-Berbasis-Web
Aplikasi Kasir dengan Menggunakan PHP dan MYSQL
Source Blog : https://www.codekop.com/read/source-code-aplikasi-penjualan-barang-kasir-dengan-php-amp-mysql-gratis.html

# Login
Login : Admin
Pass : 123 (Local User)
Jika ingin setting db tinggal ganti file Config.php nya saja
