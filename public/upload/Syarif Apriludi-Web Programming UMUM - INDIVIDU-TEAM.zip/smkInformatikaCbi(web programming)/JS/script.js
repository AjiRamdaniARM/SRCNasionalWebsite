const scroll = document.querySelector('.scroll').cloneNode(true);
document.querySelector('.testimoni').appendChild(scroll);

const tombol = document.querySelector('input');

console.log(tombol);
tombol.addEventListener('click',function(){
    document.querySelector('ul.navigasi').classList.toggle = 'menu-navigasi';
})