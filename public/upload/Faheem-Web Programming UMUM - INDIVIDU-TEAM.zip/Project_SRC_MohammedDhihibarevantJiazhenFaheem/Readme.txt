(English laguage)
This website is built to provide the latest information about robots especially for future generations of robots.

target:
1.Users understand what robots are and their importance for future generations

2.Users are up to date on the world of robotics

3.Users know information in a fun way

4.Easy to understand and enjoy

5.users feel how advanced the development of technologies such as AI

(indonesian)
Website ini dibangun untuk memberikan informasi terbaru tentang robot terutama untuk generasi robot masa depan.

Target:
1. Pengguna memahami apa itu robot dan pentingnya mereka untuk generasi mendatang

2. Pengguna up to date tentang dunia robotika

3. Pengguna mengetahui informasi dengan cara yang menyenangkan

4. Mudah dipahami dan dinikmati

5. pengguna merasakan betapa majunya perkembangan teknologi seperti AI


