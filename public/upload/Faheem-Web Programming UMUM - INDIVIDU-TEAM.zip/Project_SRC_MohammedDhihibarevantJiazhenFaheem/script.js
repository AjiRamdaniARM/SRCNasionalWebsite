

    function toggleVisibility() {
        const navLinks = document.getElementById('nav-link');
        if (navLinks.style.display === 'flex'){
            navLinks.style.display = 'none';
        }else{
            navLinks.style.display = 'flex';
        }
    }

    