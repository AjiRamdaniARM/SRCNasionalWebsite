const scrollreveal = require("scrollreveal");

function checkWidthAndHide() {
    const element = document.getElementById('slider');
    if (element.offsetWidth < 768) {
        element.style.display = 'none';
    } else {
        element.style.display = 'block';
    }
}

// Initial check
checkWidthAndHide();

// Add event listener for window resize
window.addEventListener('resize', checkWidthAndHide);

// scroll animation
ScrollReveal().reveal('.headline', {
    origin: 'top',
    distance: '50px',
    duration: 1000,
    delay: 500
  });

  ScrollReveal().reveal('.animate-image', {
    origin: 'top',
    distance: '50px',
    duration: 1000,
    delay: 500
  });
  
  ScrollReveal().reveal('.animate-title', {
    origin: 'top',
    distance: '20px',
    duration: 500,
    delay: 300
  });
  
  ScrollReveal().reveal('.animate-text', {
    origin: 'top',
    distance: '10px',
    duration: 300,
    delay: 200
  });

window.onscroll = function() {
    const navbar = document.querySelector('.navbar');
    if (window.pageYOffset > 50) {
        navbar.classList.remove('navbar-transparent');
        navbar.classList.add('navbar-solid');
    } else {
        navbar.classList.remove('navbar-solid');
        navbar.classList.add('navbar-transparent');
    }
};
