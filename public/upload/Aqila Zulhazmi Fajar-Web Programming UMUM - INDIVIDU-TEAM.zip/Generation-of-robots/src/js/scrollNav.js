const navbar = document.getElementById('navbar');
const list = document.getElementById('list');

window.addEventListener('scroll', function () {
    // if (window.scrollY > 110) {
    //     navbar.classList.add('bg-black');
    //     navbar.classList.remove('bg-transparent');
    // } else {
    //     navbar.classList.add('bg-transparent');
    //     navbar.classList.remove('bg-black');
    // }
})