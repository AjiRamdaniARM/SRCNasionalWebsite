Hai saya ruhiyat dari smk terpadu ibaddurahman dan ini project saya
project ini berisi tampilan website yang futuristic dan menarik,di project ini saya menggunakan html,css,dan java dan di dalam zip ini sudah berisi unsur/item pendukung seperti photo dll 
di menu home berisi tampilan welcome dan tema dari website ini,dan terdapat sebuah particles yang membuat kesan futuristic dan menarik
di menu berikutnya terdapat penejlasan dari mana saya berasal dan tergabung dari club apa
di menu trakhir berisi link menuju ke akun social kami

mungkin itu saja yang bisa saya deskripsikan mohon maaf atas kekurangan dalam kata kata maupun dalam project ini 